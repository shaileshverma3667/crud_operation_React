import React,{useState,useEffect} from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";

export default function Edit(){
    const [username,setUsername]=useState("");
    const [fullname,setFullname]=useState("");
    const [mobile,setMobile]=useState("");
    const [password,setPassword]=useState("");
    const [city,setCity]=useState("");
    const [massage,setMassage]=useState("");
    const [email,setEmail]=useState("");
    const {id}=useParams()
    const navigate=useNavigate()
    
    
    useEffect(()=>{
        let promise=fetch("http://localhost:8000/shailesh/"+id)
        promise.then((resp)=>{
            return resp.json()
        }).then((data)=>{
            setUsername(data.username)
            setCity(data.city)
            setEmail(data.email)
            setFullname(data.fullname)
            setMassage(data.massage)
            setMobile(data.mobile)
            setPassword(data.password)
        }).catch((error)=>{
            window.localStorage.setItem('erromessage',error.message)
        })
    },[])

    const updataData=()=>{
        let newData={
            username:username,
            fullname:fullname,
            mobile:mobile,
            password:password,
            city:city,
            massage:massage,
            email:email
        }
        let promise=fetch("http://localhost:8000/shailesh/"+id,{
            method:"PUT",
            headers:{
                'Content-type':'application/json'
            },
            body:JSON.stringify(newData)
        })
        promise.then((resp)=>{
            toast.success("data updated successfully",{position:toast.POSITION.TOP_CENTER})
            navigate('/')
        }).then((data)=>{
            console.log(data)
        }).catch((error)=>{
            window.localStorage.setItem('erromessage',error.message)
        })
    }
    return(
        <>
         <div className="container-fluid">
            <div className="row">
                <div className="offset-col-lg-3 col-lg-6 mx-auto mt-4">
                    <form>
                    <div className="card">
                        <div className="card-header">
                            <h1 className="p-2 text-center">Ragister Form...</h1>
                        </div>
                        <div className="card-body">
                            <div className="row">
                                <div className="col-lg-6">
                                    <label>UserName</label>
                                    <div className="input-group">
                                        <input type="text" value={username} onChange={(e)=>{setUsername(e.target.value)}} className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>FullName</label>
                                    <div className="input-group">
                                        <input type="text" value={fullname} onChange={(e)=>{setFullname(e.target.value)}} className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>Email</label>
                                    <div className="input-group">
                                        <input type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}}   className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>City</label>
                                    <div className="input-group">
                                        <input type="text" value={city} onChange={(e)=>{setCity(e.target.value)}}  className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-12 mb-3">
                                    <label>Message</label>
                                    <div className="input-group">
                                        <textarea className="form-control" onChange={(e)=>{setMassage(e.target.value)}} value={massage}></textarea>
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>Mobile</label>
                                    <div className="input-group">
                                        <input type="number" value={mobile} onChange={(e)=>{setMobile(e.target.value)}} className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>Password</label>
                                    <div className="input-group">
                                        <input type="password" value={password} onChange={(e)=>{setPassword(e.target.value)}}  className="form-control" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="card-footer">
                            <button className="btn btn-success ms-3"  type="button" onClick={updataData}>Update</button>
                            <Link to="/" className="btn btn-warning ms-3">Back</Link>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        </>
    );
}