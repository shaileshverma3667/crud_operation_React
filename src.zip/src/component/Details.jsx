import React, { useState,useEffect } from "react";
import { Link, useParams } from "react-router-dom";
export default function Details(){
    const[data,setData]=useState({})
    const {id}=useParams()

    useEffect(()=>{
        let promise=fetch("http://localhost:8000/shailesh/"+id)
        promise.then((resp)=>{
            return resp.json()
        }).then((data)=>{
            setData(data)
            console.log(data);
        }).catch((error)=>{
            window.localStorage.setItem('erromessage',error.message)
        })
    },[])
    return(
        <>
            <div className="container-fluid mt-4">
                <div className="row">
                    <div className="col-sm-7 mx-auto">
                        <div className="card">
                            <div className="card-header">
                                <h2 className="text-center p-2">Details Page</h2>
                            </div>
                            <div className="card-body">
                                <div className="table table-striped table-hover table-responsive">
                                    <thead className="text-center">
                                    <tr>
                                        <th>Username</th>
                                        <th>FullName</th>
                                        <th>Email</th>
                                        <th>City</th>
                                        <th>Mobile</th>
                                        <th>Message</th>
                                        <th>Password</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                                <td>{data.username}</td>
                                                <td>{data.fullname}</td>
                                                <td>{data.email}</td>
                                                <td>{data.city}</td>
                                                <td>{data.mobile}</td>
                                                <td>{data.massage}</td>
                                                <td>{data.password}</td>
                                            </tr>
                                    </tbody>
                                </div>
                            </div>
                            <div className="card-footer">
                            <Link to="/" className="btn btn-warning ms-3">Back</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
