import React, { useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function Showtable(){
    const [data,setData]=useState([])
    const navigate=useNavigate()

    useEffect(()=>{
        let promise=fetch("http://localhost:8000/shailesh")
        promise.then((resp)=>{
            return resp.json()
        }).then((data)=>{
            setData(data)
        }).catch((error)=>{
            window.localStorage.setItem('erromessage',error.message)
        })
    },[])

    const editData=(id)=>{
      navigate('/Edit/'+id)
    }
    const deleteData=(id)=>{
        let promise=fetch("http://localhost:8000/shailesh/"+id,{
            method:"DELETE",
        })
        promise.then((resp)=>{
            toast.error("data deleted successfully",{position:toast.POSITION.TOP_CENTER})
            window.location.reload()
        }).then((data)=>{
            console.log(data)
        }).catch((error)=>{
            window.localStorage.setItem('erromessage',error.message)
        })
      }
      const detailsData=(id)=>{
        navigate('/details/'+id)
      }
    return(
        <>
        <div className="container-fluid">
            <div className="row">
                <div className="col-lg-10 mx-auto">
                    <NavLink to="/create" className="btn btn-success my-3">Ragister</NavLink>
                    <div className="card">
                        <div className="card-header">
                            <h1 className="text-center p-2">Show Table</h1>
                        </div>
                        <div className="card-body">
                            <table className="table table-striped table-hover table-responsive">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>FullName</th>
                                        <th>Email</th>
                                        <th>City</th>
                                        <th>Mobile</th>
                                        <th>Message</th>
                                        <th>Password</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   {
                                     data.map((item,index)=>{
                                        return(
                                            <>
                                            <tr>
                                                <td>{item.username}</td>
                                                <td>{item.fullname}</td>
                                                <td>{item.email}</td>
                                                <td>{item.city}</td>
                                                <td>{item.mobile}</td>
                                                <td>{item.massage}</td>
                                                <td>{item.password}</td>
                                                <td>
                                                    <button className="btn btn-success ms-2" onClick={()=>editData(item.id)}>Edit</button>
                                                    <button className="btn btn-danger ms-2" onClick={()=>deleteData(item.id)}>Delete</button>
                                                    <button className="btn btn-warning ms-2" onClick={()=>detailsData(item.id)}>Details</button>
                                                </td>
                                            </tr>
                                            </>
                                            
                                        );
                                    })
                                   }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </>
    );
}