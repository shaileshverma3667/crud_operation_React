import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function Form(){
    const [username,setUsername]=useState("");
    const [fullname,setFullname]=useState("");
    const [mobile,setMobile]=useState("");
    const [password,setPassword]=useState("");
    const [city,setCity]=useState("");
    const [massage,setMassage]=useState("");
    const [email,setEmail]=useState("");
    const navigate=useNavigate()

    const isValid=()=>{
    let proseed=true;
    let massege='required compulsury'
    if(username === '' || username===null){
        toast.warning("username"+massege,{position:toast.POSITION.TOP_CENTER})
        proseed=false;
    }
    if( fullname=== '' || fullname===null){
        toast.warning("fullname"+massege,{position:toast.POSITION.TOP_CENTER})
        proseed=false;
    }
    if( mobile=== '' || mobile===null){
        toast.warning("mobile"+massege,{position:toast.POSITION.TOP_CENTER})
        proseed=false;
    }

    if( city=== '' || city===null){
        toast.warning("city"+massege,{position:toast.POSITION.TOP_CENTER})
        proseed=false;
    }

    
    return proseed;

 }

    const handleData=(e)=>{
       e.preventDefault()
       if(isValid()){
       let regid={username,fullname,mobile,password,city,massage,email}
        let promise=fetch("http://localhost:8000/shailesh",{
            method:"POST",
            headers:{
                'Content-type':'application/json'
            },
            body:JSON.stringify(regid)
        })
        promise.then((resp)=>{
            navigate('/');
            toast.success("data inserted successfully",{position:toast.POSITION.TOP_CENTER})
        }).then((data)=>{
            console.log(data)
        }).catch((error)=>{
            window.localStorage.setItem('erromessage',error.message)
        })
    }
    }
    return(
        <>
        <div className="container-fluid">
            <div className="row">
                <div className="offset-col-lg-3 col-lg-6 mx-auto mt-4">
                    <form onSubmit={handleData}>
                    <div className="card">
                        <div className="card-header">
                            <h1 className="p-2 text-center">Ragister Form...</h1>
                        </div>
                        <div className="card-body">
                            <div className="row">
                                <div className="col-lg-6">
                                    <label>UserName</label>
                                    <div className="input-group">
                                        <input type="text" value={username} onChange={(e)=>{setUsername(e.target.value)}} className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>FullName</label>
                                    <div className="input-group">
                                        <input type="text" value={fullname} onChange={(e)=>{setFullname(e.target.value)}} className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>Email</label>
                                    <div className="input-group">
                                        <input type="email" value={email} onChange={(e)=>{setEmail(e.target.value)}}   className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>City</label>
                                    <div className="input-group">
                                        <input type="text" value={city} onChange={(e)=>{setCity(e.target.value)}}  className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-12 mb-3">
                                    <label>Message</label>
                                    <div className="input-group">
                                        <textarea className="form-control" onChange={(e)=>{setMassage(e.target.value)}} value={massage}></textarea>
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>Mobile</label>
                                    <div className="input-group">
                                        <input type="number" value={mobile} onChange={(e)=>{setMobile(e.target.value)}} className="form-control" />
                                    </div>
                                </div>
                                <div className="col-lg-6 mb-3">
                                    <label>Password</label>
                                    <div className="input-group">
                                        <input type="password" value={password} onChange={(e)=>{setPassword(e.target.value)}}  className="form-control" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="card-footer">
                            <button className="btn btn-success ms-3"  type="submit">Ragister</button>
                            <Link to="/" className="btn btn-warning ms-3">Back</Link>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
        </>
    );
}