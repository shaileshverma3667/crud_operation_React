import React from "react";
import { Route, Routes } from "react-router-dom";
import Details from "./component/Details";
import Edit from "./component/Edit";
import Form from "./component/Form";
import Navbar from "./component/Navbar";
import Showtable from "./component/Showtable";
import { ToastContainer, toast } from 'react-toastify';
  import 'react-toastify/dist/ReactToastify.css';

function App(){
    return(
       <>
       <ToastContainer theme="colored"></ToastContainer>
       <Navbar/>
       <Routes>
        <Route path="/" element={<Showtable/>}/>
        <Route path="/showtable" element={<Showtable/>}/>
        <Route path="/create" element={<Form/>}/>
        <Route path="/Edit" element={<Edit/>}/>
        <Route path="/edit/:id" element={<Edit/>}/>
        <Route path="/details/:id" element={<Details/>}/>
        <Route path="/details" element={<Details/>}/>
       </Routes>
       </>
    );
}

export default App;